#' @keywords internal
#' @details Details go here.
"_PACKAGE"
